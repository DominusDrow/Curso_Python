from setuptools import setup

setup(

	name="Calculos_avz",
	version="1.0",
	description="potenccia y redondeo",
	author="Drow",
	packages=["calculos","calculos.sub_calculos"]
	)

def pote(pot,num):

	return num**pot


def multi(n1,n2):

	return n1*n2


def redondeo(num):

	return round(num)

